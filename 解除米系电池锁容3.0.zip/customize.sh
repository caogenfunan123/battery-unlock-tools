#!/system/bin/sh
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
rm -rf /data/user/0/com.miui.powerkeeper/*