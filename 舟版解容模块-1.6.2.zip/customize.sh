#!/system/bin/sh

if [ "$(id -u)" != "0" ]; then
    echo "错误: 需要root权限运行此脚本"
    exit 1
fi

if [ -z "$MODPATH" ]; then
    echo "错误: MODPATH未定义，请在Magisk模块环境中运行"
    exit 1
fi

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "/data/local/tmp/install.log"
}

echo "开始安装1.6.2舟版解容模块..."
sleep 1
echo "=== 舟版解容模块安装日志 - $(date '+%Y-%m-%d %H:%M:%S') ===" > /data/local/tmp/install.log
echo "
模块介绍：舟版解容模块通过强制设置系统电量，监听电池电流变化，模拟电池的放电和充电行为，绕过系统对电池容量的限制，从而释放电池隐藏电量，延长电池使用时间。
安装前提醒：
1、安装前请关闭机型伪装类模块
2、内核最大容量小于4000mah的不建议刷入模块
3、锂电池不建议刷入模块
"
sleep 5
echo "注意：当前版本偶发掉快充现象，有两种处理方式：
1. 卸载模块后自动恢复快充
2. 卸载模块也恢复不了快充，需要恢复出厂设置或者覆盖全量包才能恢复快充

模块安装后不可逆，因模块安装、使用导致的硬件、软件问题与开发者无关。
继续安装则默认您已知晓并同意上述内容：

音量键上：取消安装模块
音量键下：继续安装模块

120秒内未选择自动取消安装模块"

RISK_TIMEOUT=120
risk_confirmed=0
risk_canceled=0
risk_start_time=$(date +%s)

echo "风险确认倒计时开始..."
while [ $(($(date +%s) - risk_start_time)) -lt $RISK_TIMEOUT ]; do
    key_event=$(getevent -qlc 1 2>/dev/null | awk '/KEY_VOLUME/ {print $3}')

    if [ "$key_event" = "KEY_VOLUMEUP" ]; then
        risk_canceled=1
        echo "用户选择取消安装模块"
        log "用户取消安装：音量上键按下"
        break
    elif [ "$key_event" = "KEY_VOLUMEDOWN" ]; then
        risk_confirmed=1
        echo "用户确认风险，继续安装模块"
        log "用户确认风险：音量下键按下"
        break
    fi
    sleep 0.1
done

if [ $risk_confirmed -eq 0 ] && [ $risk_canceled -eq 0 ]; then
    echo "超时未选择，自动取消安装模块"
    log "安装取消：超时未选择"
    risk_canceled=1
fi

if [ $risk_canceled -eq 1 ]; then
    echo "安装已取消，模块将不会安装"
    echo "如需重新安装，请重新刷入模块"

    rm -f "/data/local/tmp/install.log" 2>/dev/null

    exit 1
fi

echo "风险确认通过，继续安装流程...
"
log "风险确认通过，继续安装模块"
sleep 2
TIMEOUT=20
single_cell=""
dual_cell=""
cell_value=""
echo "请20秒内选择手机电芯模式
音量+：单电芯
音量-：双电芯
超时默认选择双电芯"
start_time=$(date +%s)

while [ $(($(date +%s) - start_time)) -lt $TIMEOUT ]; do
    key_event=$(getevent -qlc 1 2>/dev/null | awk '/KEY_VOLUME/ {print $3}')

    if [ "$key_event" = "KEY_VOLUMEUP" ]; then
        single_cell=3600
        cell_value=3000
        break
    elif [ "$key_event" = "KEY_VOLUMEDOWN" ]; then
        dual_cell=1800
        cell_value=1500
        break
    fi
    sleep 0.1
done

if [ -z "$single_cell" ] && [ -z "$dual_cell" ]; then
    dual_cell=1800
    cell_value=1500
    echo "超时，使用默认选择：双电芯"
fi

if [ -n "$single_cell" ]; then
    echo "选择结果：单电芯"
elif [ -n "$dual_cell" ]; then
    echo "选择结果：双电芯"
fi

backup_config_files() {
    local backup_dir="/data/local/tmp/battery_backup"
    log "创建备份目录: $backup_dir"
    mkdir -p "$backup_dir"

    local config_files="/data/local/tmp/dian.log /data/local/tmp/max_dian.log /data/adb/modules/ace2pro-battery-simulator/common/battery_config.sh /data/local/tmp/total_value.log /data/local/tmp/battery_history.log /data/local/tmp/current_accumulation_factor"

    log "开始备份配置文件..."

    for config_file in $config_files; do
        if [ -f "$config_file" ]; then
            local filename=$(basename "$config_file")
            cp -f "$config_file" "$backup_dir/$filename"
            log "已备份: $config_file -> $backup_dir/$filename"
        else
            log "配置文件不存在，跳过备份: $config_file"
        fi
    done

    touch "$backup_dir/.backup_complete"
    log "配置文件备份完成"
    echo "原配置文件备份完成！"
}

backup_config_files

log "停止现有服务..."
[ -f "/data/local/tmp/.battery_watchdog.pid" ] && kill -9 $(cat "/data/local/tmp/.battery_watchdog.pid") 2>/dev/null && log "停止watchdog服务"
[ -f "/data/local/tmp/.current_monitor.pid" ] && kill -9 $(cat "/data/local/tmp/.current_monitor.pid") 2>/dev/null && log "停止current_monitor服务"
[ -f "/data/local/tmp/.battery_service.pid" ] && kill -9 $(cat "/data/local/tmp/.battery_service.pid") 2>/dev/null && log "停止battery_service服务"
[ -f "/data/local/tmp/.dclog.pid" ] && kill -9 $(cat /data/local/tmp/.dclog.pid) 2>/dev/null && log "停止dclog服务"

sleep 1

log "清理旧文件..."
files=".battery_service.pid .battery_simulate .charge_end_time .charge_start_time .current_monitor.pid .service_start_time battery_service.log dian.log max_dian.log total_value.log .battery_watchdog.pid oppo mi meizu dclog.log .dclog.pid battery_history.log install.log voltage_state pid_cleanup.log battery_uninstall.log current_accumulation_factor"

for file in $files; do
    if [ -f "/data/local/tmp/$file" ]; then
        rm -f "/data/local/tmp/$file"
        log "已删除: $file"
    fi
done

sleep 1

log "创建必要的目录和文件..."
mkdir -p /data/local/tmp

FILES="/data/local/tmp/dian.log /data/local/tmp/max_dian.log /data/local/tmp/total_value.log /data/local/tmp/.current_monitor.pid /data/local/tmp/.service_start_time /data/local/tmp/.charge_start_time /data/local/tmp/.charge_end_time /data/local/tmp/.battery_service.pid /data/local/tmp/battery_service.log /data/local/tmp/install.log /data/local/tmp/dclog.log /data/local/tmp/.dclog.pid /data/local/tmp/battery_history.log /data/local/tmp/current_accumulation_factor"

for file in $FILES; do
    if [ ! -f "$file" ]; then
        touch "$file"
        chmod 0644 "$file"
        if [ "$file" = "/data/local/tmp/current_accumulation_factor" ]; then
            echo "$cell_value" > "$file"
            log "创建电流累计系数文件并设置默认值: $file (默认值: $cell_value)"
        else
            log "创建文件: $file"
        fi
    fi
done


log "检测设备类型并创建品牌标识..."
device_brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")
device_manufacturer=$(getprop ro.product.manufacturer 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")
device_model=$(getprop ro.product.model 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")

log "设备信息: 品牌=$device_brand, 制造商=$device_manufacturer, 型号=$device_model"

if echo "$device_brand $device_manufacturer $device_model" | grep -q -E "oppo|oneplus|one|realme"; then
    log "检测为OPPO/一加/真我设备"
    echo "OPPO/一加/真我设备" > "/data/local/tmp/oppo"
    device_type="oppo"
elif echo "$device_brand $device_manufacturer $device_model" | grep -q -E "xiaomi|redmi|poco|mi"; then
    log "检测为小米设备"
    echo "小米设备" > "/data/local/tmp/mi"
    device_type="mi"
elif echo "$device_brand $device_manufacturer $device_model" | grep -q -E "meizu|flyme|mz|vivo|iqoo|motorola|moto|lenovo|nubia"; then
    log "检测为魅族/红魔努比亚/vivo/iQOO/motorola设备"
    echo "魅族/vivo/红魔努比亚/iQOO/motorola设备" > "/data/local/tmp/meizu"
    device_type="meizu"
else
    log "无法确定设备类型，默认使用OPPO/一加系标识"
    echo "OPPO/一加设备" > "/data/local/tmp/oppo"
    device_type="oppo"
fi

log "获取内核数据并智能转换..."

KERNEL_RM_PATH=""
KERNEL_FCC_PATH=""

if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_rm" ]; then
    KERNEL_RM_PATH="/sys/devices/virtual/oplus_chg/battery/battery_rm"
    log "使用OPPO/一加RM路径: $KERNEL_RM_PATH"
else
    KERNEL_RM_PATH="/sys/class/power_supply/battery/charge_counter"
    log "使用通用RM路径: $KERNEL_RM_PATH"
fi

if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_fcc" ]; then
    KERNEL_FCC_PATH="/sys/devices/virtual/oplus_chg/battery/battery_fcc"
    log "使用OPPO/一加FCC路径: $KERNEL_FCC_PATH"
else
    KERNEL_FCC_PATH="/sys/class/power_supply/battery/charge_full"
    log "使用通用FCC路径: $KERNEL_FCC_PATH"
fi

kernel_rm_raw=$(cat "$KERNEL_RM_PATH" 2>/dev/null || echo "0")
kernel_fcc_raw=$(cat "$KERNEL_FCC_PATH" 2>/dev/null || echo "0")

log "内核原始值 - RM: ${kernel_rm_raw}, FCC: ${kernel_fcc_raw}"

convert_kernel_value() {
    local value=$1
    local value_name=$2

    if [ -z "$value" ] || [ "$value" = "unknown" ] || [ "$value" -le 0 ] 2>/dev/null; then
        echo "0"
        return 1
    fi

    local device_model=$(getprop ro.product.model 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")

    local upper_name=$(echo "$value_name" | tr '[:lower:]' '[:upper:]')

    case "$upper_name" in
        "RM")
            if [ "$device_model" = "m2012k11c" ]; then
                if [ "$value" -gt 0 ] 2>/dev/null; then
                    converted_value=$((value / 100000))
                    echo "$converted_value"
                    log "特殊机型处理: $device_model, RM值 $value -> $converted_value (除以100000)"
                    return 0
                fi
            fi

            if [ "$value" -gt 30000 ]; then
                converted_value=$((value / 1000))
                echo "$converted_value"
            else
                echo "$value"
            fi
            ;;
        "FCC")
            if [ "$value" -gt 30000 ]; then
                converted_value=$((value / 1000))
                echo "$converted_value"
            elif [ "$value" -gt 300 ]; then
                echo "$value"
            else
                converted_value=$((value * 100))
                echo "$converted_value"
            fi
            ;;
        *)
            echo "$value"
            log "警告: 未知的value_name: $value_name，使用默认处理"
            ;;
    esac

    return 0
}


kernel_rm=$(convert_kernel_value "$kernel_rm_raw" "RM")
kernel_fcc=$(convert_kernel_value "$kernel_fcc_raw" "FCC")

log "转换后内核值 - RM: ${kernel_rm}mAh, FCC: ${kernel_fcc}mAh"

sleep 1
log "写入电池数据文件..."

if [ "$kernel_rm" -ge 0 ] && [ "$kernel_rm" -lt 12000 ] 2>/dev/null; then
    echo "$kernel_rm" > "/data/local/tmp/dian.log"
    log "写入dian.log: ${kernel_rm}mAh"
else
    reasonable_rm=1  # 合理的默认值
    echo "$reasonable_rm" > "/data/local/tmp/dian.log"
    log "内核RM值不合理(${kernel_rm}mAh)，使用默认值写入dian.log: ${reasonable_rm}mAh"
fi

if [ "$kernel_fcc" -gt 2000 ] && [ "$kernel_fcc" -lt 12000 ] 2>/dev/null; then
    echo "$kernel_fcc" > "/data/local/tmp/max_dian.log"
    log "写入max_dian.log: ${kernel_fcc}mAh"
else
    reasonable_fcc=4600  # 典型手机电池容量
    echo "$reasonable_fcc" > "/data/local/tmp/max_dian.log"
    log "内核FCC值不合理(${kernel_fcc}mAh)，使用默认值写入max_dian.log: ${reasonable_fcc}mAh"
fi

current_dian=$(cat "/data/local/tmp/dian.log" 2>/dev/null || echo "1")
total_value=$((current_dian * cell_value))
echo "$total_value" > "/data/local/tmp/total_value.log"
log "写入total_value.log: ${current_dian}mah * ${cell_value} = ${total_value}"

chmod 0666 /data/local/tmp/dian.log
chmod 0666 /data/local/tmp/max_dian.log
chmod 0666 /data/local/tmp/total_value.log
log "设置文件权限完成"

log "=== 安装完成摘要 ==="
log "设备类型: $device_type"
log "dian.log: $(cat /data/local/tmp/dian.log 2>/dev/null)"
log "max_dian.log: $(cat /data/local/tmp/max_dian.log 2>/dev/null)"
log "total_value.log: $(cat /data/local/tmp/total_value.log 2>/dev/null)"
log "内核原始RM值: ${kernel_rm_raw}"
log "内核原始FCC值: ${kernel_fcc_raw}"
log "转换后RM值: ${kernel_rm}"
log "转换后FCC值: ${kernel_fcc}"

echo ""
echo "安装完成!"
echo ""
echo "--------------------------分割线---------------------------"
sleep 1
echo "
使用教程在模块的webui-数据界面中，按教程填写对应配置即可。
使用教程在模块的webui-数据界面中，按教程填写对应配置即可。
使用教程在模块的webui-数据界面中，按教程填写对应配置即可。

本模块完全免费，禁止收费或商用，转载或二改请标明出处及作者
出处：解容测试群，1020725382
作者：魔改：舟自白；webui：枯黄落叶；原版作者：凌空
"
sleep 1
echo "1.6.2舟版解容模块更新日志:
- 更新了欧真加系的电流路径，精度更高
- 适配红魔努比亚系列
- 修复了webui中内核容量为0不显示的bug
- 修复结束充电后临时显示真实电量的问题
- 理论上修复scene、加加电池等app温度显示波动、卡住问题
- 额外修正放电时的电流累计系数
- 修复note12tp present值恒为1影响充电判断的问题
- 机制优化：内核低于1000mah时，进入充电状态会调整模拟电量为内核电量+电压补偿，依据电压超过阈值电压的程度补偿一定数值
- 优化代码，减少不必要的文件读取和冲突读写

- 注意：当前版本偶发打开模块webui、scene卡死重启掉模块数据和文件的情况，在webui重新设置模拟容量、最大模拟容量和电流累计系数即可，或者重刷模块也行。该bug目前难以修复，正在确定问题原因中。
"
echo "300秒内按下任意音量键可立即跳转QQ群并结束安装脚本，超时自动结束安装脚本"

join_qq_group() {
    echo "🔗 跳转到QQ群: 1020725382"

    am start -a android.intent.action.VIEW \
        -d "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=1020725382&card_type=group" \
        2>/dev/null

    if [ $? -eq 0 ]; then
        echo "✅ 跳转qq群成功"
    else
        echo "❌ 跳转q群主页失败，请手动添加QQ群: 1020725382"
    fi
}
JUMP_TIMEOUT=300
jump_start_time=$(date +%s)
jumped=0

echo "跳转倒计时开始..."
while [ $(($(date +%s) - jump_start_time)) -lt $JUMP_TIMEOUT ]; do
    key_event=$(getevent -qlc 1 2>/dev/null | awk '/KEY_VOLUME/ {print $3}')

    if [ "$key_event" = "KEY_VOLUMEUP" ] || [ "$key_event" = "KEY_VOLUMEDOWN" ]; then
        echo "检测到音量键按下，立即跳转QQ群"
        join_qq_group
        jumped=1
        break
    fi
    sleep 0.1
done

if [ $jumped -eq 0 ]; then
    echo "超时未按下音量键，自动跳转QQ群"
    join_qq_group
fi

exit 0

exit 0
