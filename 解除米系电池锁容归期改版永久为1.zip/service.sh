#!/system/bin/sh

MODDIR="${0%/*}"
LOGFILE="$MODDIR/run.log"

: > "$LOGFILE"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"
}

log "===== 电池循环固定为1模块启动 ====="

# 等待开机完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done
log "开机已完成"

# 等待解锁进入桌面
while true; do
    if (pidof com.miui.home >/dev/null || pidof com.android.launcher >/dev/null); then
        if dumpsys window 2>/dev/null | grep -q "mDreamingLockscreen=false"; then
            break
        fi
    fi
    sleep 2
done
log "已解锁并进入桌面"

NODE="/sys/class/qcom-battery/fake_cycle"
MAX_WAIT=300
WAIT=0

# 等待节点可写
while [ $WAIT -lt $MAX_WAIT ]; do
    if [ -f "$NODE" ] && echo 0 > "$NODE" 2>/dev/null; then
        log "电池节点已就绪，5秒后执行"
        break
    fi
    WAIT=$((WAIT + 5))
    log "等待节点…已等待 ${WAIT}s"
    sleep 5
done

if [ $WAIT -ge $MAX_WAIT ]; then
    log "❌ 节点超时"
    exit 1
fi

sleep 5

# 直接固定为 1
read_cycle() {
    val=$(cat "$NODE" 2>/dev/null | tr -cd '0-9')
    [ -z "$val" ] && val=0
    echo "$val"
}

log "当前循环次数 = $(read_cycle)"

echo 1 > "$NODE" 2>/dev/null

now=$(read_cycle)
if [ "$now" -eq 1 ]; then
    log "✅ 成功固定电池循环次数为：1"
else
    log "❌ 修改失败"
fi

log "===== 执行结束 ====="