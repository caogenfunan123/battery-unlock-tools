#!/bin/bash
#
# k60_build_module.sh - build k60_fcc_unlock.ko against the stock
# android12-5.10.136 GKI tree with clang-r416183b, matching the device
# vermagic 5.10.136-android12-9-00003-g8970630c07cd.
#
# Only GKI-stable symbols (register_kprobe/unregister_kprobe) are used, so
# the module's symbol CRCs match those exported by the device kernel.
#
# Usage:  bash k60_build_module.sh
set -euo pipefail

ROOT=/tmp/opencode/ddk
SRC=/tmp/opencode/gki136
CLANG=$ROOT/clang-r416183b
OUT=$ROOT/out
MODDIR=/workspace/k60-battery-unlock/kernel

DEVICE_VERMAGIC="android12-9-00003-g8970630c07cd"
BUILD_NUM="9368044"

export ARCH=arm64
export LLVM=1
export LLVM_IAS=1
export CROSS_COMPILE=aarch64-linux-gnu-
export PATH="$CLANG/bin:$PATH"

mkdir -p "$OUT"

echo "==> [1/4] configure gki_defconfig (qcom)"
make -C "$SRC" O="$OUT" gki_defconfig

echo "==> [2/4] inject device vermagic suffix"
"$SRC/scripts/config" --file "$OUT/.config" \
    --set-str CONFIG_LOCALVERSION "-$DEVICE_VERMAGIC"

# also apply Android suffix via the KMI generation mechanism: the kernel
# version string becomes "5.10.136-android12-9-00003-g8970630c07cd"
echo "==> [3/4] modules_prepare (generates Module.symvers + vermagic)"
make -C "$SRC" O="$OUT" modules_prepare

echo "==> [4/4] build external module"
make -C "$SRC" O="$OUT" M="$MODDIR" modules

echo ""
echo "==> RESULT =="
ls -la "$MODDIR/k60_fcc_unlock.ko"
echo "verify vermagic:"
"$CLANG/bin/llvm-readelf" -p .modinfo "$MODDIR/k60_fcc_unlock.ko" 2>/dev/null \
    | grep -i vermagic || strings "$MODDIR/k60_fcc_unlock.ko" | grep vermagic
