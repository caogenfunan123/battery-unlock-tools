#!/system/bin/sh

export VOLTAGE_THRESHOLD=3150000
export DIAN_MAX_THRESHOLD=6100
export FORCE_DISCHARGE_VALUE=200
export SHM_DIR="/dev/shm/simulator"

export OPPO_FILE="/data/local/tmp/oppo"
export MI_FILE="/data/local/tmp/mi"
export MEIZU_FILE="/data/local/tmp/meizu"

export OPPO_CURRENT_PATH="/sys/devices/virtual/oplus_chg/battery/bcc_parms"
export CURRENT_PATH="/sys/class/power_supply/battery/current_now"

if [ -f "/sys/class/power_supply/battery/voltage_min" ]; then
    VOLTAGE_PATH="/sys/class/power_supply/battery/voltage_min"
else
    VOLTAGE_PATH="/sys/class/power_supply/battery/voltage_now"
fi
export VOLTAGE_PATH

export TEMP_PATH="/sys/class/power_supply/battery/temp"
export CAPACITY_PATH="/sys/class/power_supply/battery/capacity"
export CHARGE_FULL="/sys/class/power_supply/battery/charge_full"
export CHARGE_COUNTER="/sys/class/power_supply/battery/charge_counter"

export USB_ONLINE_PATH="/sys/class/power_supply/usb/online"
export USB_PRESENT_PATH="/sys/class/power_supply/usb/present"

if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_rm" ]; then
    KERNEL_RM_PATH="/sys/devices/virtual/oplus_chg/battery/battery_rm"
else
    KERNEL_RM_PATH="/sys/class/power_supply/battery/charge_counter"
fi

if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_fcc" ]; then
    KERNEL_FCC_PATH="/sys/devices/virtual/oplus_chg/battery/battery_fcc"
else
    KERNEL_FCC_PATH="/sys/class/power_supply/battery/charge_full"
fi

export KERNEL_RM_PATH
export KERNEL_FCC_PATH

export SIMULATE_PATH="/data/local/tmp/.battery_simulate"
export SERVICE_PID_FILE="/data/local/tmp/.battery_service.pid"
export WATCHDOG_PID_FILE="/data/local/tmp/.battery_watchdog.pid"
export DCLOG_PID_FILE="/data/local/tmp/.dclog.pid"
export CURRENT_MONITOR_PID_FILE="/data/local/tmp/.current_monitor.pid"
export LOG_FILE="/data/local/tmp/battery_service.log"

export DIAN_LOG="/data/local/tmp/dian.log"
export MAX_DIAN_LOG="/data/local/tmp/max_dian.log"
export TOTAL_VALUE_LOG="/data/local/tmp/total_value.log"
export CURRENT_ACCUMULATION_FACTOR_FILE="/data/local/tmp/current_accumulation_factor"

export START_TIME_FILE="/data/local/tmp/.service_start_time"
export CHARGE_START_TIME_FILE="/data/local/tmp/.charge_start_time"
export CHARGE_END_TIME_FILE="/data/local/tmp/.charge_end_time"

export WATCHDOG_INTERVAL=60
export LOG_LOOP_INTERVAL=3
export TEMP_MONITOR_ENABLED=1
export RM_ADJUST=2

export BATTERY_DESIGN_CAPACITY=4600
export MAX_DIAN_THRESHOLD=10000
export MAX_DIAN_MIN_THRESHOLD=4000
export DIAN_DECREMENT_STEP=50
export CHARGE_DURATION_THRESHOLD=300
export CHARGE_END_SPECIAL_PERIOD=20

export DEFAULT_TEMP=250
export DEFAULT_CHARGE_FULL=4600000
export DEFAULT_CHARGE_COUNTER=0
export DEFAULT_KERNEL_RM=0
export DEFAULT_KERNEL_FCC=1
export DEFAULT_REAL_PERCENT=50

read_from_shm() {
    local file_name="$1"
    local default_value="$2"
    local shm_file="$SHM_DIR/$file_name"

    if [ -f "$shm_file" ] && [ -r "$shm_file" ]; then
        cat "$shm_file" 2>/dev/null || echo "$default_value"
    else
        local disk_file="/data/local/tmp/$file_name"
        if [ -f "$disk_file" ]; then
            cat "$disk_file" 2>/dev/null || echo "$default_value"
        else
            echo "$default_value"
        fi
    fi
}

write_to_shm() {
    local file_name="$1"
    local value="$2"
    local shm_file="$SHM_DIR/$file_name"

    mkdir -p "$SHM_DIR" 2>/dev/null
    echo "$value" > "$shm_file" 2>/dev/null
}

get_device_type() {
    if [ -f "$SHM_DIR/oppo" ]; then
        echo "oppo"
    elif [ -f "$SHM_DIR/mi" ]; then
        echo "mi"
    elif [ -f "$SHM_DIR/meizu" ]; then
        echo "meizu"
    else
        if [ -f "$OPPO_FILE" ]; then
            echo "oppo"
        elif [ -f "$MI_FILE" ]; then
            echo "mi"
        elif [ -f "$MEIZU_FILE" ]; then
            echo "meizu"
        else
            echo "unknown"
        fi
    fi
}
