// 修复版的完整 kernelsu.js 代码
let callbackCounter = 0;
const activeCallbacks = new Map();
const MAX_CONCURRENT_COMMANDS = 5;
const COMMAND_TIMEOUT = 8000;

function getUniqueCallbackName(prefix) {
    return `${prefix}_callback_${Date.now()}_${callbackCounter++}_${Math.random().toString(36).substr(2, 8)}`;
}

function cleanupCallback(callbackName) {
    try {
        if (window[callbackName]) {
            delete window[callbackName];
        }
        activeCallbacks.delete(callbackName);
    } catch (error) {
        console.warn('清理回调函数失败:', error);
    }
}

// 定期清理僵尸回调
function startZombieCallbackCleanup() {
    const cleanupInterval = setInterval(() => {
        // 检查是否在浏览器环境中运行
        if (typeof window === 'undefined') {
            clearInterval(cleanupInterval);
            return;
        }
        
        const now = Date.now();
        let cleanedCount = 0;
        
        for (const [callbackName, callbackInfo] of activeCallbacks) {
            // 如果回调存在超过超时时间的2倍，认为是僵尸回调
            if (now - callbackInfo.startTime > COMMAND_TIMEOUT * 2) {
                console.warn(`清理僵尸回调: ${callbackName}, 命令: ${callbackInfo.command.substring(0, 50)}...`);
                cleanupCallback(callbackName);
                cleanedCount++;
            }
        }
        
        if (cleanedCount > 0) {
            console.warn(`清理了 ${cleanedCount} 个僵尸回调`);
        }
    }, 30000);
}

// 启动僵尸回调清理
if (typeof window !== 'undefined') {
    startZombieCallbackCleanup();
}

export function exec(command, options = {}) {
    return new Promise((resolve) => {
        // 安全检查：确保在浏览器环境中运行
        if (typeof window === 'undefined') {
            resolve({ errno: 1, stdout: "", stderr: "非浏览器环境" });
            return;
        }

        // 检查并发命令数量限制
        if (activeCallbacks.size >= MAX_CONCURRENT_COMMANDS) {
            console.warn(`命令执行被限制，当前活跃命令: ${activeCallbacks.size}, 最大允许: ${MAX_CONCURRENT_COMMANDS}`);
            resolve({ errno: 1, stdout: "", stderr: "系统繁忙，请稍后重试" });
            return;
        }

        const callbackFuncName = getUniqueCallbackName("exec");
        const timeout = options.timeout || COMMAND_TIMEOUT;
        
        // 记录命令开始时间和信息
        const commandStartTime = Date.now();
        activeCallbacks.set(callbackFuncName, {
            startTime: commandStartTime,
            command: command.substring(0, 100), // 只记录部分命令用于调试
            timeoutId: null
        });
        
        // 超时保护
        const timeoutId = setTimeout(() => {
            console.warn(`命令执行超时 (${timeout}ms): ${command.substring(0, 50)}...`);
            
            // 从activeCallbacks中移除
            if (activeCallbacks.has(callbackFuncName)) {
                activeCallbacks.delete(callbackFuncName);
            }
            
            cleanupCallback(callbackFuncName);
            resolve({ errno: 1, stdout: "", stderr: "命令执行超时" });
        }, timeout);

        // 更新存储的timeoutId
        activeCallbacks.get(callbackFuncName).timeoutId = timeoutId;
        
        window[callbackFuncName] = (errno, stdout, stderr) => {
            // 清理超时定时器
            clearTimeout(timeoutId);
            
            // 计算执行时间
            const executionTime = Date.now() - commandStartTime;
            if (executionTime > 2000) {
                console.warn(`命令执行较慢: ${executionTime}ms - ${command.substring(0, 50)}...`);
            }
            
            // 确保从activeCallbacks中移除
            if (activeCallbacks.has(callbackFuncName)) {
                activeCallbacks.delete(callbackFuncName);
            }
            
            cleanupCallback(callbackFuncName);
            resolve({ errno, stdout, stderr });
        };
        
        try {
            if (typeof ksu !== 'undefined' && ksu.exec) {
                ksu.exec(command, JSON.stringify(options), callbackFuncName);
            } else {
                clearTimeout(timeoutId);
                
                // 确保从activeCallbacks中移除
                if (activeCallbacks.has(callbackFuncName)) {
                    activeCallbacks.delete(callbackFuncName);
                }
                
                cleanupCallback(callbackFuncName);
                resolve({ errno: 1, stdout: "", stderr: "ksu is not available" });
            }
        } catch (error) {
            clearTimeout(timeoutId);
            
            // 确保从activeCallbacks中移除
            if (activeCallbacks.has(callbackFuncName)) {
                activeCallbacks.delete(callbackFuncName);
            }
            
            cleanupCallback(callbackFuncName);
            resolve({ errno: 1, stdout: "", stderr: error.message });
        }
    });
}

export function toast(message, duration = 'SHORT') {
    try {
        if (typeof ksu !== 'undefined' && ksu.toast) {
            ksu.toast(message, duration);
        } else {
            console.log(`[TOAST] ${message}`);
        }
    } catch (error) {   
        console.warn("Error displaying toast:", error);
    }
}

// 清理所有回调
export function cleanup() {
    // 清理所有活跃的回调
    let cleanedCount = 0;
    for (const [callbackName, callbackInfo] of activeCallbacks) {
        // 清理定时器
        if (callbackInfo.timeoutId) {
            clearTimeout(callbackInfo.timeoutId);
        }
        cleanupCallback(callbackName);
        cleanedCount++;
    }
    activeCallbacks.clear();
    
    if (cleanedCount > 0) {
        console.log(`清理了 ${cleanedCount} 个活跃回调`);
    }
}

// 获取当前活跃命令数量
export function getActiveCommandsCount() {
    return activeCallbacks.size;
}

// 获取当前活跃命令信息（用于调试）
export function getActiveCommandsInfo() {
    const commands = [];
    for (const [callbackName, info] of activeCallbacks) {
        commands.push({
            callbackName,
            command: info.command,
            runningTime: Date.now() - info.startTime,
            timeoutId: info.timeoutId
        });
    }
    return commands;
}

// 检查KSU可用性
export function isKSUAvailable() {
    return typeof ksu !== 'undefined' && ksu.exec && ksu.toast;
}

// 健康检查
export function healthCheck() {
    return {
        activeCommands: activeCallbacks.size,
        maxConcurrent: MAX_CONCURRENT_COMMANDS,
        isKSUAvailable: isKSUAvailable(),
        memoryUsage: performance && performance.memory ? {
            usedJSHeapSize: Math.round(performance.memory.usedJSHeapSize / 1048576) + 'MB',
            totalJSHeapSize: Math.round(performance.memory.totalJSHeapSize / 1048576) + 'MB',
            jsHeapSizeLimit: Math.round(performance.memory.jsHeapSizeLimit / 1048576) + 'MB'
        } : 'Not available',
        callbackCounter: callbackCounter
    };
}

// 紧急停止所有命令
export function emergencyStop() {
    console.error('执行紧急停止，取消所有待处理命令');
    const stoppedCount = activeCallbacks.size;
    
    for (const [callbackName, callbackInfo] of activeCallbacks) {
        // 清理定时器
        if (callbackInfo.timeoutId) {
            clearTimeout(callbackInfo.timeoutId);
        }
        
        // 立即返回超时错误
        try {
            if (window[callbackName]) {
                window[callbackName](1, "", "命令被紧急停止");
            }
        } catch (error) {
            console.warn('执行紧急回调失败:', error);
        }
        
        cleanupCallback(callbackName);
    }
    
    activeCallbacks.clear();
    console.log(`紧急停止了 ${stoppedCount} 个命令`);
    return stoppedCount;
}

// 导出默认对象
export default {
    exec,
    toast,
    cleanup,
    getActiveCommandsCount,
    getActiveCommandsInfo,
    isKSUAvailable,
    healthCheck,
    emergencyStop
};