#!/system/bin/sh

MODDIR="${0%/*}"
LOGFILE="$MODDIR/run.log"

: > "$LOGFILE"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"
}

log "===== 模块启动 ====="

# 等待开机完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done
log "开机已完成"

# 等待解锁进入桌面
while true; do
    if (pidof com.miui.home >/dev/null || pidof com.android.launcher >/dev/null); then
        if dumpsys window | grep -q "mDreamingLockscreen=false"; then
            break
        fi
    fi
    sleep 2
done
log "已解锁并进入桌面"

# 电池节点
NODE="/sys/class/qcom-battery/fake_cycle"
MAX_WAIT=300
WAIT=0

# 等待节点可写
while [ "$WAIT" -lt "$MAX_WAIT" ]; do
    if [ -f "$NODE" ] && [ -w "$NODE" ]; then
        log "电池节点已就绪，5秒后执行"
        break
    fi
    WAIT=$((WAIT + 5))
    log "等待节点…已等待 ${WAIT}s"
    sleep 5
done

if [ "$WAIT" -ge "$MAX_WAIT" ]; then
    log "❌ 节点超时"
    exit 1
fi

sleep 5
log "开始读取并修改循环次数"

# 读取当前循环次数
read_cycle() {
    val="$(cat "$NODE" 2>/dev/null | tr -cd '0-9')"
    [ -z "$val" ] && val=0
    echo "$val"
}

# 循环次数区间
fix_cycle() {
    chmod 777 "$NODE"
    val=$(read_cycle)
    log "当前实际循环次数= $val"

    if [ "$val" -lt 100 ]; then
        new=1
    elif [ "$val" -ge 101 ] && [ "$val" -le 300 ]; then
        new=10
    elif [ "$val" -ge 301 ] && [ "$val" -le 500 ]; then
        new=20
    elif [ "$val" -ge 501 ] && [ "$val" -le 700 ]; then
        new=50
    elif [ "$val" -ge 701 ] && [ "$val" -le 900 ]; then
        new=80
    elif [ "$val" -ge 901 ] && [ "$val" -le 1000 ]; then
        new=100
    elif [ "$val" -ge 1001 ]; then
        new=200
    else
        chmod 644 "$NODE"
        return 0
    fi

    # 修改次数后并验证
    if echo "$new" > "$NODE"; then
        now=$(read_cycle)
        log "✅ 已修改为：$new次循环"
    else
        log "❌ 修改失败"
        chmod 644 "$NODE"
        return 1
    fi

    chmod 644 "$NODE"
    return 0
}

fix_cycle

log "===== 执行结束 ====="
