#!/system/bin/sh

MODDIR=${0%/*}

smart_merge_config() {
    local backup_file="$1"
    local current_file="$2"

    if [ -f "$current_file" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开始合并配置..." >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

        if ! grep -q "export DEFAULT_REAL_PERCENT=" "$current_file"; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] 检测到DEFAULT_REAL_PERCENT缺失，从备份恢复" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
            backup_line=$(grep "export DEFAULT_REAL_PERCENT=" "$backup_file" 2>/dev/null | head -1)
            if [ -n "$backup_line" ]; then
                echo "$backup_line" >> "$current_file"
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] 已添加: $backup_line" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
            fi
        fi

        for config in VOLTAGE_THRESHOLD DIAN_MAX_THRESHOLD FORCE_DISCHARGE_VALUE WATCHDOG_INTERVAL LOG_LOOP_INTERVAL RM_ADJUST; do
            backup_value=$(grep "^export $config=" "$backup_file" 2>/dev/null | sed "s/^export $config=//")
            if [ -n "$backup_value" ]; then
                sed -i "s/^export $config=.*/export $config=$backup_value/" "$current_file" 2>/dev/null
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] 替换数值: $config=$backup_value" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
            fi
        done

        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 配置合并完成" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

    else
        cp -f "$backup_file" "$current_file"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 使用备份配置文件" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
    fi
}

restore_backup_if_exists() {
    local backup_dir="/data/local/tmp/battery_backup"

    if [ -d "$backup_dir" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 检测到旧版本配置，开始恢复配置文件..." >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

        mkdir -p "/data/local/tmp"

        if [ -f "$backup_dir/dian.log" ]; then
            cp -f "$backup_dir/dian.log" "/data/local/tmp/dian.log"
        fi

        if [ -f "$backup_dir/max_dian.log" ]; then
            cp -f "$backup_dir/max_dian.log" "/data/local/tmp/max_dian.log"
        fi

        if [ -f "$backup_dir/total_value.log" ]; then
            cp -f "$backup_dir/total_value.log" "/data/local/tmp/total_value.log"
        fi

        if [ -f "$backup_dir/battery_history.log" ]; then
            cp -f "$backup_dir/battery_history.log" "/data/local/tmp/battery_history.log"
        fi
        if [ -f "$backup_dir/current_accumulation_factor" ]; then
            cp -f "$backup_dir/current_accumulation_factor" "/data/local/tmp/current_accumulation_factor"
        fi

        if [ -f "$backup_dir/battery_config.sh" ]; then
            mkdir -p "/data/adb/modules/ace2pro-battery-simulator/common/"

            local current_config="/data/adb/modules/ace2pro-battery-simulator/common/battery_config.sh"
            local backup_config="$backup_dir/battery_config.sh"

            if [ ! -f "$current_config" ]; then
                cp -f "$backup_config" "$current_config"
            else
                smart_merge_config "$backup_config" "$current_config"
            fi
        fi

        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 备份恢复完成" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
    fi
}

cleanup_backup_directory() {
    local backup_dir="/data/local/tmp/battery_backup"

    if [ -d "$backup_dir" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 清理备份文件夹: $backup_dir" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
        rm -rf "$backup_dir"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 备份文件夹不存在，无需清理" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
    fi
}

check_and_set_permissions() {
    local bin_files="/system/bin/battery_simulator /system/bin/dclog /system/bin/battery_current_monitor"

    for bin_file in $bin_files; do
        if [ -f "$bin_file" ]; then
            if [ ! -x "$bin_file" ]; then
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] 设置执行权限: $bin_file" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
                chmod 755 "$bin_file"
            fi
        else
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警告: 二进制文件不存在: $bin_file，模块未挂载到系统，请更换root管理器或寻找其它方法挂载模块" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
        fi
    done
}
copy_files_to_shared_memory() {
    local source_dir="/data/local/tmp"
    local target_dir="/dev/shm/simulator"

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开始复制关键文件到内存目录..." >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

    mkdir -p "$target_dir" 2>/dev/null && chmod 0777 "$target_dir" 2>/dev/null

    local files_to_copy=".charge_end_time .charge_start_time .service_start_time current_accumulation_factor dian.log max_dian.log oppo mi meizu total_value.log"
    local copied_count=0

    for file in $files_to_copy; do
        if [ -f "$source_dir/$file" ] && cp -f "$source_dir/$file" "$target_dir/$file" 2>/dev/null; then
            chmod 0666 "$target_dir/$file" 2>/dev/null
            copied_count=$((copied_count + 1))
        fi
    done

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 文件复制完成: 成功 $copied_count 个文件" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
    return 0
}

main() {
    restore_backup_if_exists

    check_and_set_permissions

    local count=0
    local success_count=0
    local fcc_value=0

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开始获取电池FCC值..." >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

    while [ $success_count -lt 3 ] && [ $count -lt 10 ]; do
        count=$((count + 1))
        local current_fcc=$(cat /sys/class/power_supply/battery/charge_full 2>/dev/null)

        if [ -n "$current_fcc" ] && [ "$current_fcc" -gt 0 ] 2>/dev/null; then
            success_count=$((success_count + 1))
            fcc_value="$current_fcc"  # 更新最终值

            if [ $success_count -ge 3 ]; then
                break
            fi
        else
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✗ 第$count次尝试失败（偶尔出现此报错是正常情况）" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
        fi

        sleep 1
    done

    if [ $success_count -ge 3 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] FCC值确认有效: 成功${success_count}次, 最终值: ${fcc_value}" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警告: FCC值获取未达到要求 (成功${success_count}/3次)" >> "/data/local/tmp/battery_service.log" 2>/dev/null || true
        fcc_value=${fcc_value:-0}  # 如果fcc_value为空，设置为0
    fi
    copy_files_to_shared_memory
    sleep 1
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 等待启动服务中..." >> "/data/local/tmp/battery_service.log" 2>/dev/null || true

    sleep 3
    /system/bin/battery_simulator --start-service >/dev/null 2>&1 &

    sleep 3
    /system/bin/dclog >/dev/null 2>&1 &

    cleanup_backup_directory
}

main

exit 0
